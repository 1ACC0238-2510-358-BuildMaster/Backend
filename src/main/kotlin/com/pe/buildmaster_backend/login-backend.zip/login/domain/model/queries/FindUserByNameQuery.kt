package com.pe.buildmaster_backend.login.domain.model.queries

data class FindUserByNameQuery(
    val name: String
)